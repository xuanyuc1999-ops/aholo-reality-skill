#!/usr/bin/env python3
"""Reconstruct photos, videos, an INSV/OSV or a Hesai project, or add photos or videos to a reconstruction. Install: python -m pip install requests numpy pillow.

Set RECONSTRUCTION_API_KEY. Example:
python reconstruct.py photos/ --base-url https://HOST/api/web-scan/v1 --camera camera.json
python reconstruct.py extra/ --base-url https://HOST/api/web-scan/v1 --reconstruction ID
python reconstruct.py --insv VID_0001.insv --base-url https://HOST/api/web-scan/v1 --out results-insv
python reconstruct.py --video clip1.mp4 --video clip2.mp4 --base-url https://HOST/api/web-scan/v1 --out results-video
python reconstruct.py --hesai PROJECT_FOLDER --base-url https://HOST/api/web-scan/v1 --out results-hesai
Videos, INSV, OSV and a Hesai project's files are uploaded in resumable parts and decoded by the service; rerun the same
command to resume. A Hesai Kosmo One project folder is uploaded whole, its LiDAR files included (downloadable again
from the API), and reconstructed with the scanner's recipe from its photos and device poses.
Add --include cameras masks to download camera poses and masks; the default is models and scale only.
Use --models ply, spz, both (default) or none to select model downloads without starting another job.
Coordinates follow OpenCV (right, down, forward); without supplied poses the model is levelled (+Y down, along gravity).
--axes manycore asks the job for PLY and SPZ right, forward, up (default: PLY right, down, forward; SPZ right, up, back).
--public-access gives the job public URLs that a service without a key can download (printed, and kept in receipt.json).
--max-gaussians 15000000 raises the trained model's Gaussian ceiling (default 4000000): longer training, larger files.
--steps 100000 sets how many steps the job trains (1000-1440000; default: the service's own budget): training time grows in proportion.
--epochs 30 sets passes over the images instead of steps (the service counts them when it trains, at most 1440000 steps).
--image-size 3840 sets the photos' size for --video (the longest edge, never upscaled) or --insv (the lens edge, default 2560).
--skip-pose-refinement keeps the poses in --inputs exactly as given (ground truth): every image needs camera_to_world or
device_to_world, every camera its params, and the cameras come back at those poses; without it they are refined.
Photos are uploaded as they are: the service turns them upright by their EXIF orientation, as the web import does. A photo
that a camera definition, a mask, a pose or IMU refers to must already be upright as stored (EXIF orientation 1), since
turning it would move what those describe; the client lists any that are not and uploads nothing until they are fixed.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import timezone
from email.utils import parsedate_to_datetime
import hashlib
import io
import json
import mimetypes
import os
from pathlib import Path
import re
import time
import shutil
import sys
import tempfile
import threading
from zipfile import ZipFile
from urllib.parse import urljoin, urlsplit
import uuid

import requests

MAX_GAUSSIANS = 4_000_000   # the service's default ceiling on a job's Gaussians (job option max_gaussians)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def retry_delay(value, fallback=3, now=None):
    """Honor both RFC Retry-After forms; preserve resume state rather than retry before a long deadline."""
    if value is None:
        seconds = fallback
    elif value.strip().isdigit():
        seconds = int(value.strip())
    else:
        try:
            date = parsedate_to_datetime(value)
            if date.tzinfo is None:
                date = date.replace(tzinfo=timezone.utc)
            seconds = max(0, date.timestamp() - (time.time() if now is None else now))
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError('Invalid Retry-After header; resume after checking the service response.') from error
    if seconds > 60:
        raise RuntimeError(f'The service requested {seconds:g}s before retrying, beyond this client’s 60s wait budget. '
                           'Wait that long, then rerun the same command to resume.')
    return seconds



def exif_orientation(path):
    """A photo's EXIF orientation as the service reads it (Pillow: EXIF, else XMP); 1 is upright as stored. A file
    Pillow cannot read counts as 1: the service then refuses it with its own reason."""
    from PIL import Image, UnidentifiedImageError
    try:
        with Image.open(path) as image:
            return image.getexif().get(274, 1)
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
        return 1


def not_upright(rows, local_file, tied):
    """(file, orientation) of each photo that must be upright as stored but is not: every photo when `tied` (a declared
    camera or IMU), otherwise those with a mask or a pose. The service would refuse them; the client does not turn their
    pixels itself, since the camera parameters, masks, poses or IMU axes would have to turn with them."""
    poses = ('camera_to_world', 'device_to_world')
    named = [row['file'] for row in rows
             if tied or row.get('mask') or any(row.get('metadata', {}).get(k) is not None for k in poses)]
    try:
        import PIL  # noqa: F401
    except ImportError:   # the service still refuses such a photo, at its upload
        if named:
            print('Pillow is not installed (python -m pip install pillow): EXIF orientations are not checked before '
                  'uploading.', file=sys.stderr, flush=True)
        return []
    return [(name, orientation) for name in named if (orientation := exif_orientation(local_file(name))) != 1]


def imu_chunks(path, samples_per_segment=1_000_000):
    """Split large NPZ input using disk-backed arrays; memory use stays within one upload segment."""
    import numpy as np
    required = {'timestamps', 'gyro_rad_s', 'R_rig_imu'}
    optional = {'time_offset_s', 'max_gap_s', 'break_before', 'rotation_sigma_scale'}
    if not 1 <= path.stat().st_size <= 4 * 1024**3:
        raise ValueError('IMU input must be a numeric NPZ up to 4 GiB; multiple files may be supplied in time order.')
    with ZipFile(path) as archive, tempfile.TemporaryDirectory(prefix='reconstruction-imu-') as temporary:
        items = archive.infolist()
        names = [item.filename for item in items]
        if (len(names) != len(set(names)) or not {key+'.npy' for key in required} <= set(names)
                or set(names) - {key+'.npy' for key in required | optional}
                or sum(item.file_size for item in items) > 4 * 1024**3):
            raise ValueError('Invalid or oversized IMU NPZ contents.')
        arrays = {}
        for item in items:
            with archive.open(item) as source:
                version = np.lib.format.read_magic(source)
                if version not in ((1, 0), (2, 0)):
                    raise ValueError('Unsupported IMU NPY version.')
                reader = np.lib.format.read_array_header_1_0 if version == (1, 0) else np.lib.format.read_array_header_2_0
                shape, _, dtype = reader(source, max_header_size=4096)
                if (len(shape) > 2 or dtype.kind not in 'fibu' or dtype.itemsize > 8
                        or any(n < 0 or n > 100_000_000 for n in shape)
                        or int(np.prod(shape, dtype=object))*dtype.itemsize + source.tell() != item.file_size):
                    raise ValueError('Invalid IMU array shape, type or length.')
            target = Path(temporary) / item.filename
            with archive.open(item) as source, target.open('wb') as output:
                shutil.copyfileobj(source, output, length=1024**2)
            arrays[item.filename[:-4]] = np.load(target, mmap_mode='r', allow_pickle=False)
        count = len(arrays['timestamps'])
        if (arrays['timestamps'].ndim != 1 or not 3 <= count <= 100_000_000
                or arrays['gyro_rad_s'].shape != (count, 3)
                or ('break_before' in arrays and arrays['break_before'].shape != (count,))):
            raise ValueError('IMU timestamps, XYZ gyro and optional breaks must have matching sample counts.')
        offset = 0
        while offset < count:
            stop = min(offset + samples_per_segment, count)
            if 0 < count - stop < 3:
                stop -= 3 - (count - stop)
            chunk = {key: array[offset:stop] if key in ('timestamps', 'gyro_rad_s', 'break_before') else array
                     for key, array in arrays.items()}
            output = io.BytesIO()
            np.savez(output, **chunk)
            yield offset, output.getvalue()
            offset = stop

def api_base(args, parser):
    base = args.base_url.rstrip('/')
    parsed = urlsplit(base)
    if parsed.username or parsed.password or parsed.query or parsed.fragment or not parsed.netloc:
        parser.error('--base-url must be an API URL without credentials, query or fragment.')
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in ('localhost', '127.0.0.1', '::1')):
        parser.error('Use HTTPS (HTTP is allowed only on loopback for local testing).')
    return base


def resume_state(args, parser, fingerprint, **initial):
    """The resume state in --out: a stable Idempotency-Key and progress, bound to these inputs and options."""
    args.out.mkdir(parents=True, exist_ok=True)
    state_path = args.out / 'request.json'
    if state_path.exists():
        if state_path.stat().st_size > 8 * 1024 * 1024:
            raise ValueError('The resume state is larger than 8 MiB.')
        state = json.loads(state_path.read_text())
    else:
        state = dict(fingerprint=fingerprint, key=str(uuid.uuid4()), **initial)
    if state['fingerprint'] != fingerprint:
        parser.error('This output directory belongs to different inputs/options. Use a new --out directory.')
    def save_state():
        partial = state_path.with_suffix('.tmp')
        partial.write_text(json.dumps(state, indent=2) + '\n')
        partial.replace(state_path)
    save_state()
    return state, save_state


class ApiError(RuntimeError):
    def __init__(self, status, detail):
        super().__init__(f'{status}: {detail}')
        self.status = status


def client(base, token):
    """request(method, url, ...): one session per thread, retries only for stable request identities."""
    local = threading.local()

    def request(method, url, **kwargs):
        if urlsplit(url)[:2] != urlsplit(base)[:2]:
            raise ValueError('Refusing to send an API key to a different origin.')
        if not hasattr(local, 'session'):
            local.session = requests.Session()
            local.session.headers['Authorization'] = 'Bearer ' + token
        # Only retry operations whose identity is stable: GET, the same image or part PUT, or a keyed POST.
        for attempt in range(4):
            try:
                response = local.session.request(method, url, timeout=(10, 120), **kwargs)
            except (requests.Timeout, requests.ConnectionError):
                if attempt == 3:
                    raise
                time.sleep(2 ** attempt)
                continue
            if response.status_code in (429, 500, 502, 503, 504) and attempt < 3:
                value = response.headers.get('Retry-After')
                response.close()
                time.sleep(retry_delay(value, 2 ** attempt))
                continue
            if not response.ok:
                try:
                    detail = response.json().get('detail', response.reason)
                except ValueError:
                    detail = response.reason
                raise ApiError(response.status_code, detail)
            return response
        raise RuntimeError('Request retries exhausted.')
    return request


PART_BYTES = 8 * 1024**2


def file_identity(path):
    """SHA-256 of the first MiB, the last MiB and the decimal size: the file's identity for resuming."""
    size = path.stat().st_size
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        digest.update(stream.read(min(size, 1 << 20)))
        stream.seek(max(0, size - (1 << 20)))
        digest.update(stream.read(1 << 20))
    digest.update(str(size).encode('ascii'))
    return digest.hexdigest()


def upload_parts(request, url, path, received, order, parallel, kind):
    """PUT the parts of path, in order, that received (part -> SHA-256) lacks; the service checks X-Content-SHA256."""
    def send(part):
        with path.open('rb') as stream:
            stream.seek(part * PART_BYTES)
            data = stream.read(PART_BYTES)
        digest = hashlib.sha256(data).hexdigest()
        known = received.get(str(part))
        if known is None:
            request('PUT', f'{url}/parts/{part}', data=data,
                    headers={'Content-Type': 'application/octet-stream', 'X-Content-SHA256': digest})
        elif known != digest:
            raise RuntimeError(f'Part {part} differs from the uploaded file; select the original {kind}.')

    with ThreadPoolExecutor(parallel) as pool:
        for done, _ in enumerate(pool.map(send, order), 1):
            if done % 16 == 0 or done == len(order):
                print(f'Uploaded {kind} parts {done}/{len(order)} ({done / len(order):.0%})', flush=True)


def insv_bootstrap_parts(path):
    """The parts the service starts decoding from (the trailer index and its records, the MP4 moov box, the first and
    last part and the last MiB), read from the trailer and box headers only, as the application's page does
    (lib/insv.ts insvBootstrapParts): uploaded first, they let the service decode while the rest uploads. [] when the
    file is not laid out so or needs more than the service's 256 parts: it then decodes once the upload is complete.
    A trailer with no index (older cameras') or without the gyro or exposure record gets the parts holding its metadata
    record, from which the service refuses another camera's file; the page reads the camera model itself, this client
    leaves it to the service."""
    size = path.stat().st_size
    count = -(-size // PART_BYTES)
    parts = {0, count - 1}

    def include(start, end):
        parts.update(range(start // PART_BYTES, (end - 1) // PART_BYTES + 1))

    with path.open('rb') as stream:
        def read(start, length):
            if start < 0 or not 1 <= length <= 65536 or start + length > size:
                raise ValueError('out of bounds')
            stream.seek(start)
            data = stream.read(length)
            if len(data) != length:
                raise ValueError('short read')
            return data

        try:
            footer = read(size - 78, 78)
            trailer_size, index_size = int.from_bytes(footer[38:42], 'little'), int.from_bytes(footer[2:6], 'little')
            if (footer[46:78] != b'8db42d694ccc418790edff439fe026bf' or int.from_bytes(footer[42:46], 'little') != 3
                    or not 78 <= trailer_size <= size):
                return []
            include(max(0, size - (1 << 20)), size)   # the resume fingerprint reads the last MiB too
            if footer[0] or footer[1] or not index_size or index_size > 65536 or index_size % 10:
                # Records chained back from the footer, the metadata last (the ONE X2's): it ends in the last MiB.
                chained = footer[0] == footer[1] == 1 and 0 < index_size <= min(65536, trailer_size - 78)
                return sorted(parts) if chained else []
            trailer_start, index_start = size - trailer_size, size - 78 - index_size
            if index_start < trailer_start:
                return []
            include(index_start, size)
            index, records, extents = read(index_start, index_size), set(), []
            for offset in range(0, index_size, 10):
                tag, kind = index[offset], index[offset + 1]
                length = int.from_bytes(index[offset + 2:offset + 6], 'little')
                start = trailer_start + int.from_bytes(index[offset + 6:offset + 10], 'little')
                if not length:
                    continue
                if start + length > index_start:
                    return []
                extents.append((start, start + length))
                if tag not in (1, 3, 4, 12):
                    continue
                if tag in records or length > (65536 if tag == 1 else 1024**3) or kind != (1 if tag == 1 else 0):
                    return []
                records.add(tag)
                include(start, start + length)
            extents.sort()
            if any(b[0] < a[1] for a, b in zip(extents, extents[1:])):
                return []
            if not {1, 3, 4} <= records:   # the records it has, the metadata among them
                return sorted(parts) if 1 in records and len(parts) <= 256 else []
            position = 0
            for _ in range(4096):
                if position >= trailer_start:
                    break
                if trailer_start - position < 8:
                    return []
                header = read(position, min(16, trailer_start - position))
                size32 = int.from_bytes(header[:4], 'big')
                if size32 == 1 and len(header) < 16:
                    return []
                length = int.from_bytes(header[8:16], 'big') if size32 == 1 else size32 or trailer_start - position
                if not (16 if size32 == 1 else 8) <= length <= trailer_start - position:
                    return []
                if header[4:8] == b'moov':
                    include(position, position + length)
                    return sorted(parts) if len(parts) <= 256 else []
                position += length
            return []
        except ValueError:
            return []


def insv_main(args, parser, token):
    """Upload an INSV or OSV in resumable 8 MiB parts; the service imports it and queues the job itself."""
    path = args.insv.resolve()
    if not path.is_file() or path.suffix.lower() not in ('.insv', '.osv') or not 78 <= path.stat().st_size <= 64 * 1024**3:
        parser.error('--insv must be an .insv or .osv file of at most 64 GiB.')
    kind = path.suffix[1:].upper()
    if not 0.5 <= args.fps <= 60:
        parser.error('--fps must be between 0.5 and 60.')
    base = api_base(args, parser)
    size, identity = path.stat().st_size, file_identity(path)
    fingerprint = hashlib.sha256(json.dumps([base, 'insv', path.name, size, identity, args.fps, args.name,
                                             *([args.axes] if args.axes != 'opencv' else []),
                                             *(['public'] if args.public_access else []),
                                             *([args.max_gaussians] if args.max_gaussians != MAX_GAUSSIANS else []),
                                             *([{'steps': args.steps}] if args.steps else []),
                                             *([{'epochs': args.epochs}] if args.epochs else []),
                                             *([{'image_size': args.image_size}] if args.image_size else []),
                                             *(['keep-people'] if args.keep_people else [])],
                                            sort_keys=True).encode()).hexdigest()
    state, save_state = resume_state(args, parser, fingerprint)
    request = client(base, token)
    pid = request('POST', base + '/reconstructions', json={'name': args.name, 'pose_units': 'relative', **people_option(args)},
                  headers={'Idempotency-Key': state['key']}).json()['id']
    state['reconstruction_id'] = pid
    save_state()
    print('Reconstruction:', pid, flush=True)
    url = base + '/reconstructions/' + pid + '/insv'
    bootstrap = insv_bootstrap_parts(path)
    start = {'name': path.name, 'size': size, 'fingerprint': identity, 'fps': args.fps,
             **({'image_size': args.image_size} if args.image_size else {}),
             **({'bootstrap_parts': bootstrap} if bootstrap else {})}
    upload = request('POST', url, json=start).json()   # creates, resumes or reads the import
    if upload['part_size'] != PART_BYTES or upload['part_count'] != -(-size // PART_BYTES):
        raise RuntimeError(f'Unexpected {kind} part layout; update this client.')
    # Run again on a failed import, this run retries it: complete once every part is in. A held one (a video the
    # service does not read yet) takes the rest of its parts first, so that its retry needs no new upload.
    retry, uploads = upload['status'] == 'failed', upload['status'] in ('uploading', 'paused') or upload.get('held')
    if uploads:
        for attempt in range(2):
            try:
                if upload['status'] == 'paused':
                    upload = request('POST', url, json=start).json()   # another import paused it: resume
                first = set(bootstrap)   # what the service decodes from, then the video in order
                order = bootstrap + [part for part in range(upload['part_count']) if part not in first]
                upload_parts(request, url, path, upload['received'], order, args.parallel, kind)
                break
            except ApiError as error:   # paused by another import of this account, or refused, while uploading
                upload = request('GET', url).json()
                if error.status != 409 or upload['status'] not in ('paused', 'failed') or upload['status'] == 'paused' and attempt:
                    raise
                if upload['status'] == 'failed':   # reported below
                    break
        upload = request('GET', url).json()   # failed while it uploaded: reported below, not completed
    if uploads and upload['status'] != 'failed' or retry and upload['received_count'] == upload['part_count']:
        upload = request('POST', url + '/complete', json={'output_formats': ['ply', 'spz'], **job_options(args)}).json()
    deadline = time.monotonic() + args.timeout
    reported = None
    while not upload['job_id']:
        if upload['status'] in ('failed', 'paused', 'uploading'):
            again = ' (its parts are kept: rerun the same command to retry it)' if upload.get('held') else ''
            raise RuntimeError(f'{kind} import {upload["status"]}: {upload["error"] or "rerun the same command to resume"}{again}')
        progress = (upload['status'], upload['phase'], upload['done'], upload['total'])
        if progress != reported:
            print(f'{kind} import:', upload['status'], upload['phase'] or '', f'{upload["done"]}/{upload["total"]}' if upload['total'] else '', flush=True)
            reported = progress
        if time.monotonic() >= deadline:
            raise TimeoutError(f'The import continues in the service; rerun the same command to resume polling {url}.')
        response = request('GET', url)
        time.sleep(retry_delay(response.headers.get('Retry-After')))
        upload = response.json()
    print(f'{kind} imported: {upload["image_count"]} photos', flush=True)
    state['job_id'] = upload['job_id']
    save_state()
    download(args, request, base, pid, state, save_state, fingerprint, None)


HESAI_LIST, HESAI_READY = 'Project Data/session_info.json', 'Project Data/.ready_for_transfer'


def storage_request(method, url, **kwargs):
    """A signed request to object storage: no API key (another origin), retried on network and 5xx failures."""
    for attempt in range(4):
        try:
            response = requests.request(method, url, timeout=(10, 300), **kwargs)
        except (requests.Timeout, requests.ConnectionError):
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)
            continue
        if response.status_code >= 500 and attempt < 3:
            time.sleep(2 ** attempt)
            continue
        if not response.ok or b'<Error>' in response.content[:4096]:
            raise ApiError(response.status_code, 'object storage: ' + response.text[:300])
        return response
    raise RuntimeError('Request retries exhausted.')


def hesai_file(request, url, folder, entry, parallel):
    """One file of the project: its parts uploaded (object storage's multipart upload by signed requests, or PUT to the
    service), the upload completed and the file marked received."""
    url = f"{url}/files/{entry['file']}"
    path = folder / entry['path']
    upload = request('POST', url).json()
    if upload['part_bytes'] != PART_BYTES or upload['part_count'] != max(1, -(-entry['bytes'] // PART_BYTES)):
        raise RuntimeError('Unexpected Hesai part layout; update this client.')
    missing = [part for part in range(upload['part_count']) if str(part) not in upload['received']]
    if not upload['remote']:
        upload_parts(request, url, path, upload['received'], list(range(upload['part_count'])), parallel, 'Hesai project')
    elif missing:
        if upload['start']:   # object storage's multipart upload, started once: its UploadId kept by the service
            answer = storage_request('POST', upload['start']['url'], headers=upload['start']['headers'])
            found = re.search(r'<UploadId>([^<]+)</UploadId>', answer.text)
            if not found:
                raise RuntimeError('Object storage answered the start without an UploadId.')
            request('POST', url + '/upload', json={'upload_id': found.group(1)})

        def send(part, signed):
            with path.open('rb') as stream:
                stream.seek(part * PART_BYTES)
                data = stream.read(PART_BYTES)
            answer = storage_request('PUT', signed['url'], data=data, headers=signed['headers'])
            return {'part': part, 'sha256': hashlib.sha256(data).hexdigest(), 'etag': answer.headers['ETag']}
        with ThreadPoolExecutor(parallel) as pool:
            for start in range(0, len(missing), 64):
                batch = missing[start:start + 64]
                urls = request('POST', url + '/parts', json={'parts': batch}).json()['urls']
                receipts = list(pool.map(lambda part: send(part, urls[str(part)]), batch))
                request('POST', url + '/parts/complete', json={'parts': receipts})
    completion = request('POST', url + '/complete').json()
    if completion.get('url'):
        storage_request('POST', completion['url'], data=completion['body'].encode(), headers=completion['headers'])
    request('POST', url + '/received')


def hesai_main(args, parser, token):
    """Upload every standard file of a Hesai Kosmo One project folder, the LiDAR's included, in the order the service
    lists them: it imports the photos and device poses as they arrive and queues the job with the scanner's recipe."""
    folder = args.hesai.resolve()
    listed = folder / HESAI_LIST
    if not listed.is_file() or listed.stat().st_size > 1 << 20:
        parser.error('--hesai must be a Hesai project folder: its Project Data/session_info.json is missing.')
    session = listed.read_bytes().decode('utf-8')
    try:
        files = [{'path': f['name'], 'size': f['size']} for f in json.loads(session)['files']]
    except (ValueError, KeyError, TypeError):
        parser.error("--hesai: the project's session_info.json cannot be read.")
    files.append({'path': HESAI_LIST, 'size': len(session.encode())})
    if (folder / HESAI_READY).is_file():
        files.append({'path': HESAI_READY, 'size': (folder / HESAI_READY).stat().st_size})
    for f in files:   # as the service checks them: the folder whole, as the scanner wrote it
        if not (folder / f['path']).is_file() or (folder / f['path']).stat().st_size != f['size']:
            parser.error(f"--hesai: {f['path']} is missing or not the size the project lists; copy the whole folder again.")
    base = api_base(args, parser)
    options = {**({'axes': args.axes} if args.axes != 'opencv' else {}), **({'public_access': True} if args.public_access else {})}
    fingerprint = hashlib.sha256(json.dumps([base, 'hesai', hashlib.sha256(session.encode()).hexdigest(), args.name, options],
                                            sort_keys=True).encode()).hexdigest()
    state, save_state = resume_state(args, parser, fingerprint)
    request = client(base, token)
    pid = request('POST', base + '/reconstructions', json={'name': args.name},
                  headers={'Idempotency-Key': state['key']}).json()['id']
    state['reconstruction_id'] = pid
    save_state()
    print('Reconstruction:', pid, flush=True)
    url = base + '/reconstructions/' + pid + '/hesai'
    body = {'session': session, 'files': files, 'output_formats': ['ply', 'spz'], **options}
    project = request('POST', url, json=body).json()   # creates, resumes or reads the import
    if project['status'] == 'failed':   # tried afresh by its POST above; its files are kept
        project = request('GET', url).json()
    sent = sum(f['bytes'] for f in project['files'] if f['received'])
    for entry in project['files']:
        if entry['received']:
            continue
        try:
            hesai_file(request, url, folder, entry, args.parallel)
        except ApiError as error:   # paused by another Hesai import of this account: resumed once
            if error.status != 409 or request('GET', url).json()['status'] != 'paused':
                raise
            request('POST', url, json=body)
            hesai_file(request, url, folder, entry, args.parallel)
        sent += entry['bytes']
        print(f"Uploaded {entry['path']} ({sent / project['bytes']:.0%} of the project)", flush=True)
    deadline = time.monotonic() + args.timeout
    reported = None
    while not project['job_id']:
        if project['status'] in ('failed', 'paused'):
            raise RuntimeError(f"Hesai import {project['status']}: {project['error'] or 'rerun the same command to resume'}")
        progress = (project['status'], project['phase'], project['done'], project['total'])
        if progress != reported:
            print('Hesai import:', project['status'], project['phase'] or '',
                  f"{project['done']}/{project['total']}" if project['total'] else '', flush=True)
            reported = progress
        if time.monotonic() >= deadline:
            raise TimeoutError(f'The import continues in the service; rerun the same command to resume polling {url}.')
        response = request('GET', url)
        time.sleep(retry_delay(response.headers.get('Retry-After')))
        project = response.json()
    print(f"Hesai project imported: {project['done']} photos", flush=True)
    state['job_id'] = project['job_id']
    save_state()
    download(args, request, base, pid, state, save_state, fingerprint, None)


def video_main(args, parser, token):
    """Append ordinary videos in resumable 8 MiB parts; once the service has decoded them all, one job reconstructs them."""
    paths = [path.resolve() for path in args.video]
    if any(not path.is_file() or path.suffix.lower() not in ('.mp4', '.mov', '.m4v', '.mkv', '.webm', '.avi')
           or not 1 <= path.stat().st_size <= 64 * 1024**3 for path in paths):
        parser.error('Each --video must be an MP4, MOV, M4V, MKV, WebM or AVI file of at most 64 GiB.')
    if len(set(paths)) != len(paths):
        parser.error('Each --video must name a different file.')
    if not 0.5 <= args.fps <= 60:
        parser.error('--fps must be between 0.5 and 60.')
    base = api_base(args, parser)
    fingerprint = hashlib.sha256(json.dumps([base, 'video', args.reconstruction, args.name, args.fps, args.mode,
                                             [[path.name, path.stat().st_size, file_identity(path)] for path in paths],
                                             *([args.axes] if args.axes != 'opencv' else []),
                                             *(['public'] if args.public_access else []),
                                             *([args.max_gaussians] if args.max_gaussians != MAX_GAUSSIANS else []),
                                             *([{'steps': args.steps}] if args.steps else []),
                                             *([{'epochs': args.epochs}] if args.epochs else []),
                                             *([{'image_size': args.image_size}] if args.image_size else []),
                                             *(['keep-people'] if args.keep_people else [])],
                                            sort_keys=True).encode()).hexdigest()
    state, save_state = resume_state(args, parser, fingerprint, phase='uploading')
    request = client(base, token)
    # a rerun keeps the reconstruction it made: a decoded video adds its camera there, so the same create would differ
    pid = args.reconstruction or state.get('reconstruction_id') or request(
        'POST', base + '/reconstructions', json={'name': args.name, **people_option(args)},
        headers={'Idempotency-Key': state['key']}).json()['id']
    state['reconstruction_id'] = pid
    save_state()
    print('Reconstruction:', pid, flush=True)
    url = base + '/reconstructions/' + pid
    if state['phase'] == 'uploading':
        import_videos(args, request, url, paths, uuid.UUID(state['key']))
        state['phase'] = 'submitting'   # a rerun after a lost job response leaves the running job's inputs alone
        save_state()
    options = {'output_formats': ['ply', 'spz'], 'mode': args.mode, 'skip_pose_refinement': False, **job_options(args),
               **people_option(args)}   # an existing reconstruction's own choice too
    download(args, request, base, pid, state, save_state, fingerprint,
             lambda: request('POST', url + '/jobs', json=options, headers={'Idempotency-Key': state['key']}))


def import_videos(args, request, url, paths, key):
    """Upload each video and queue its decoding while the next uploads, then wait until every one is decoded."""
    videos = []
    for index, path in enumerate(paths):
        size = path.stat().st_size
        video = request('POST', url + '/videos', json={'name': path.name, 'size': size, 'fps': args.fps,
                                                       **({'image_size': args.image_size} if args.image_size else {})},
                        headers={'Idempotency-Key': uuid.uuid5(key, f'video:{index}').hex}).json()
        if video['part_bytes'] != PART_BYTES or video['part_count'] != -(-size // PART_BYTES):
            raise RuntimeError('Unexpected video part layout; update this client.')
        video_url = url + '/videos/' + video['id']
        if video['status'] == 'uploading':
            upload_parts(request, video_url, path, video['received'], range(video['part_count']), args.parallel, path.name)
        if video['status'] in ('uploading', 'error'):   # an error is retried from the original the service keeps
            deadline = time.monotonic() + args.timeout
            while True:
                try:
                    request('POST', video_url + '/complete')
                    break
                except ApiError as error:   # the account already has three imports queued or decoding
                    if error.status != 429 or time.monotonic() >= deadline:
                        raise
                    time.sleep(10)
        videos.append((path, video_url))
    deadline = time.monotonic() + args.timeout
    for path, video_url in videos:
        reported = None
        while True:
            response = request('GET', video_url)
            video = response.json()
            if video['status'] == 'done':
                break
            if video['status'] == 'cancelled':
                raise RuntimeError(f'{path.name} import was cancelled; use a new --out directory to import it again.')
            if video['status'] == 'error':
                raise RuntimeError(f'{path.name} import failed: {video["error"]} Rerun the same command to retry it.')
            progress = video['status'], 10 * video['done'] // video['total'] if video['total'] else 0
            if progress != reported:
                print(f'{path.name} import:', video['status'], f'{video["done"]}/{video["total"]}' if video['total'] else '', flush=True)
                reported = progress
            if time.monotonic() >= deadline:
                raise TimeoutError(f'The import continues in the service; rerun the same command to resume polling {video_url}.')
            time.sleep(retry_delay(response.headers.get('Retry-After')))
        print(f'{path.name} imported: {video["total"]} photos', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('photos', type=Path, nargs='?', help='Directory of photos; omit with --video or --insv')
    parser.add_argument('--video', type=Path, action='append', help='Ordinary MP4, MOV, M4V, MKV, WebM or AVI video; '
                        'repeat for several. The service decodes each at --fps, then one job reconstructs them together')
    parser.add_argument('--insv', type=Path, help='Insta360 dual-lens .insv or DJI Osmo 360 .osv; the service decodes, '
                        'calibrates and reconstructs it')
    parser.add_argument('--hesai', type=Path, help='Hesai Kosmo One project folder: every standard file is uploaded, the '
                        "LiDAR's included, and the service reconstructs it with the scanner's recipe")
    parser.add_argument('--fps', type=float, default=5, help='Video frames or INSV/OSV frame pairs sampled per second (0.5-60)')
    parser.add_argument('--parallel', type=int, default=4, choices=range(1, 5), metavar='1-4', help='Video/INSV/OSV parts uploaded at once')
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--name', default='API reconstruction')
    parser.add_argument('--camera', type=Path, help='Camera JSON: model, width, height and optional params (also for fisheye)')
    parser.add_argument('--inputs', type=Path, help='JSON with camera/cameras and images: file, camera_id, metadata, mask, mask_type')
    parser.add_argument('--imu', type=Path, action='append', help='Raw gyro NPZ; repeat in time order to append. Large files are split automatically.')
    parser.add_argument('--mode', choices=['scene', 'object'], default='scene')
    parser.add_argument('--axes', choices=['opencv', 'manycore'], default='opencv',
                        help='Model file axes: opencv (PLY right/down/forward, SPZ right/up/back) or manycore (both right/forward/up)')
    parser.add_argument('--public-access', action='store_true',
                        help='Public URLs for the results that need no key; turn them off with PUT /reconstructions/{id}/jobs/{job_id}/public_access')
    parser.add_argument('--max-gaussians', type=int, default=MAX_GAUSSIANS,
                        help='Most Gaussians the trained model may have (100000-15000000, default 4000000); higher trains longer and makes larger files')
    parser.add_argument('--steps', type=int, help='Training steps (1000-1440000); default: the service\'s own budget, the larger of '
                        '20000 and 8 passes over the images, or 40 passes for images from an ordinary video and 20 from an INSV '
                        'or OSV. Training time grows in proportion')
    parser.add_argument('--epochs', type=int, help='Training passes over the images instead of --steps (at least 1); the '
                        'service turns them into steps by the images it trains, at least 1000 and at most 1440000')
    parser.add_argument('--image-size', type=int, help='Photo size in pixels for --video (the longest edge; default: the '
                        'video\'s own, never upscaled) or --insv (the lens edge, 480-8192 and even; default 2560, at most the source)')
    parser.add_argument('--keep-people', action='store_true',
                        help='Keep people such as statues and figures in paintings; mask only the camera operator (remove_people false)')
    parser.add_argument('--skip-pose-refinement', action='store_true', help='Keep the poses in --inputs exactly as '
                        'given: every image needs one and every camera its params (default: refine them)')
    parser.add_argument('--object-image', help='Relative image filename used to select an object')
    parser.add_argument('--object-box', nargs=4, type=float, metavar=('LEFT', 'TOP', 'RIGHT', 'BOTTOM'))
    parser.add_argument('--reconstruction', help='Append photos or videos to this existing reconstruction')
    parser.add_argument('--out', type=Path, default=Path('results'), help='Results and resume state; use a new directory for a new job')
    parser.add_argument('--models', choices=['both', 'ply', 'spz', 'none'], default='both',
                        help='Model downloads only; ply/spz/both include scale.json, none skips models and scale. Does not change the job.')
    parser.add_argument('--include', nargs='+', choices=['cameras', 'masks'], default=[],
                        help='Optional downloads; default: models and scale only. Reuse --out to download more from the same job.')
    parser.add_argument('--timeout', type=int, default=72 * 3600, help='Maximum seconds to wait for video imports, then for the job (default 72 h)')
    args = parser.parse_args()
    token = os.environ.get('RECONSTRUCTION_API_KEY')
    if not token:
        parser.error('Set RECONSTRUCTION_API_KEY in the environment.')
    if not 100_000 <= args.max_gaussians <= 15_000_000:
        parser.error('--max-gaussians must be between 100000 and 15000000.')
    if args.steps is not None and not 1_000 <= args.steps <= 1_440_000:
        parser.error('--steps must be between 1000 and 1440000.')
    if args.epochs is not None and not 1 <= args.epochs <= 1_440_000:
        parser.error('--epochs must be between 1 and 1440000.')
    if args.steps is not None and args.epochs is not None:
        parser.error('Use --steps or --epochs, not both.')
    if args.image_size is not None:
        if not (args.video or args.insv):
            parser.error('--image-size is for --video and --insv.')
        if not 480 <= args.image_size <= 8192 or args.insv and args.image_size % 2:
            parser.error('--image-size must be between 480 and 8192 (even for --insv).')
    if args.video:
        if args.insv or args.photos or args.camera or args.inputs or args.imu or args.object_image or args.object_box \
                or args.skip_pose_refinement:
            parser.error('--video takes no photos, INSV, camera, inputs, IMU, pose or object selection options.')
        return video_main(args, parser, token)
    if args.hesai:
        if args.video or args.insv or args.photos or args.camera or args.inputs or args.imu or args.reconstruction \
                or args.mode != 'scene' or args.object_image or args.skip_pose_refinement or args.keep_people \
                or args.max_gaussians != MAX_GAUSSIANS or args.steps or args.epochs or args.image_size:
            parser.error("--hesai takes no other inputs, existing reconstruction or training options: the scanner's recipe "
                         'reconstructs it.')
        return hesai_main(args, parser, token)
    if args.insv:
        if args.photos or args.camera or args.inputs or args.imu or args.reconstruction or args.mode != 'scene' \
                or args.object_image or args.skip_pose_refinement:
            parser.error('--insv takes no photos, camera, inputs, IMU, pose, existing reconstruction or object options.')
        return insv_main(args, parser, token)
    if not args.photos or not args.photos.is_dir():
        parser.error('The photos path must be a directory.')
    if args.camera and args.inputs:
        parser.error('Use --camera or --inputs, not both.')
    if args.skip_pose_refinement and not args.inputs:
        parser.error('--skip-pose-refinement keeps the poses given in --inputs; supply them there.')
    if bool(args.object_image) != bool(args.object_box) or (args.object_image and args.mode != 'object'):
        parser.error('Object selection needs --mode object, --object-image and --object-box together.')
    if args.object_box:
        left, top, right, bottom = args.object_box
        if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
            parser.error('--object-box coordinates must satisfy 0 <= left < right <= 1 and 0 <= top < bottom <= 1.')
    root = args.photos.resolve()
    def local_file(name):
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('Input files must be inside the photos directory.')
        return path
    def read_json(path):
        if path.stat().st_size > 8 * 1024 * 1024:
            raise ValueError('Input JSON is larger than 8 MiB.')
        return json.loads(path.read_text())
    inputs = read_json(args.inputs) if args.inputs else {}
    declared_imu = inputs.get('imu', [])
    if isinstance(declared_imu, str):
        declared_imu = [declared_imu]
    imu = [path.resolve() for path in args.imu] if args.imu else [local_file(name) for name in declared_imu]
    if any(not path.is_file() or path.stat().st_size > 4 * 1024**3 for path in imu):
        parser.error('Each IMU source must be a numeric NPZ file up to 4 GiB.')
    rows = inputs.get('images') if args.inputs else [dict(file=p.name) for p in sorted(root.iterdir())
        if p.is_file() and p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.webp')]
    if not isinstance(rows, list) or not rows or len(rows) > 30000:
        parser.error('The directory contains no JPEG, PNG or WebP images.')
    if len({row['file'] for row in rows}) != len(rows):
        parser.error('Each image filename must occur once.')
    for row in rows:
        if row.get('mask_type', 'binary') not in ('binary', 'alpha'):
            parser.error('mask_type must be binary or alpha.')
        if local_file(row['file']).stat().st_size > 12 * 1024 * 1024:
            parser.error('An image exceeds 12 MiB.')
        if row.get('mask') and local_file(row['mask']).stat().st_size > 8 * 1024 * 1024:
            parser.error('A mask exceeds 8 MiB.')
    if args.object_image and args.object_image not in {row['file'] for row in rows}:
        parser.error('--object-image must be present in this upload.')
    base = api_base(args, parser)
    body = {'name': args.name, **people_option(args), **{k: inputs[k] for k in ('camera', 'cameras', 'pose_units') if k in inputs}}
    if args.camera:
        body['camera'] = read_json(args.camera)
    files = {row[k]: sha256(local_file(row[k])) for row in rows for k in ('file', 'mask') if row.get(k)}
    for index, path in enumerate(imu):
        files['__imu_npz__' if len(imu) == 1 else f'__imu_npz_{index}__'] = sha256(path)
    fingerprint = hashlib.sha256(json.dumps([base, args.reconstruction, body, rows, files, args.mode,
        args.skip_pose_refinement, args.object_image, args.object_box, *([args.axes] if args.axes != 'opencv' else []),
        *(['public'] if args.public_access else []), *([args.max_gaussians] if args.max_gaussians != MAX_GAUSSIANS else []),
        *([{'steps': args.steps}] if args.steps else []), *([{'epochs': args.epochs}] if args.epochs else [])],
        sort_keys=True).encode()).hexdigest()   # --skip-pose-refinement: False in every fingerprint before it
    state, save_state = resume_state(args, parser, fingerprint, uploaded=0, phase='uploading')
    request = client(base, token)
    existing = request('GET', base + '/reconstructions/' + args.reconstruction).json() if args.reconstruction else {}
    tied = bool(args.camera or imu or any(k in inputs for k in ('camera', 'cameras')) or existing.get('cameras')
                or existing.get('imu'))
    if turned := not_upright(rows, local_file, tied):
        listed = [f'  {name}: EXIF orientation {orientation}' for name, orientation in turned[:20]]
        parser.error('\n'.join([
            f'{len(turned)} photos are not upright as stored (EXIF orientation 1), but a camera definition, mask, pose or '
            'IMU refers to their pixel grid, so the service would refuse them:', *listed,
            *([f'  and {len(turned) - 20} more'] if len(turned) > 20 else []),
            'Turn their pixels upright, saved with EXIF orientation 1, and transform the camera parameters, masks, poses '
            'or IMU axes to match (Cameras in the developer guide); or upload them without those inputs, and the service '
            'turns them upright itself.']))

    if args.reconstruction:
        if args.camera or any(k in inputs for k in ('camera', 'cameras', 'pose_units')):
            parser.error('An existing reconstruction retains its cameras and pose units; omit their definitions.')
        pid = args.reconstruction
    else:
        pid = request('POST', base + '/reconstructions', json=body,
                      headers={'Idempotency-Key': state['key']}).json()['id']
    url = base + '/reconstructions/' + pid
    if 'sequence' not in state:
        sequence, cursor = 0, -1
        while True:
            page = request('GET', url + '/images', params={'cursor': cursor, 'limit': 1000}).json()
            sequence = max(sequence, max((row['sequence'] + 1 for row in page['items']), default=0))
            cursor = page['next_cursor']
            if cursor is None:
                break
        state.update(reconstruction_id=pid, sequence=sequence)
        save_state()
    print('Reconstruction:', pid, flush=True)
    ids = {}
    for offset, row in enumerate(rows):
        photo = local_file(row['file'])
        fid = uuid.uuid5(uuid.UUID(state['key']), row['file']).hex
        ids[row['file']] = fid
        if offset < state['uploaded'] or state['phase'] != 'uploading':
            continue
        params = {'sequence': state['sequence'] + offset}
        if row.get('camera_id'):
            params['camera_id'] = row['camera_id']
        image_url = url + '/images/' + fid
        request('PUT', image_url, params=params, data=photo.read_bytes(),
                headers={'Content-Type': mimetypes.guess_type(photo.name)[0] or 'image/jpeg'})
        if row.get('metadata'):
            request('PUT', image_url + '/metadata', json=row['metadata'])
        if row.get('mask'):
            request('PUT', image_url + '/mask', params={'mask_type': row.get('mask_type', 'binary')},
                    data=local_file(row['mask']).read_bytes(), headers={'Content-Type': 'image/png'})
        state['uploaded'] = offset + 1
        save_state()
        print(f'Uploaded {offset + 1}/{len(rows)}: {photo.name}', flush=True)
    part_index = 0
    for file_index, path in enumerate(imu):
        for offset, data in imu_chunks(path):
            if part_index >= state.get('imu_uploaded', 0):
                segment_id = uuid.uuid5(uuid.UUID(state['key']), f'imu:{file_index}:{offset}').hex
                request('PUT', url+'/imu/segments/'+segment_id, data=data,
                        headers={'Content-Type': 'application/octet-stream'})
                state['imu_uploaded'] = part_index + 1
                save_state()
                print(f'Uploaded IMU segment {part_index + 1}: {path.name}, sample {offset}', flush=True)
            part_index += 1
    # An upload response acknowledges bytes, while preprocessing may still be running.
    deadline = time.monotonic() + args.timeout
    while state['phase'] != 'submitting':
        pending, cursor = 0, -1
        while True:
            page = request('GET', url + '/images', params={'cursor': cursor, 'limit': 1000}).json()
            if any(row['status'] == 'failed' for row in page['items']):
                raise RuntimeError('An image failed preprocessing; inspect its status before submitting a job.')
            pending += sum(row['status'] != 'ready' for row in page['items'])
            cursor = page['next_cursor']
            if cursor is None:
                break
        if not pending:
            break
        if time.monotonic() >= deadline:
            raise TimeoutError(f'Preprocessing timed out for {pending} images in {pid}.')
        time.sleep(2)
    options = {'output_formats': ['ply', 'spz'], 'mode': args.mode, 'skip_pose_refinement': args.skip_pose_refinement,
               **job_options(args), **people_option(args)}   # an existing reconstruction's people choice too
    if args.object_image:
        options['object_selection'] = {'image_id': ids[args.object_image], 'bounding_box': args.object_box}
    state['phase'] = 'submitting'
    save_state()
    download(args, request, base, pid, state, save_state, fingerprint,
             lambda: request('POST', url + '/jobs', json=options, headers={'Idempotency-Key': state['key']}))


def job_options(args):
    """The job's axes, public access, Gaussian ceiling and steps or passes, sent only when not the default (an older service does not know them)."""
    return {**({'axes': args.axes} if args.axes != 'opencv' else {}), **({'public_access': True} if args.public_access else {}),
            **({'max_gaussians': args.max_gaussians} if args.max_gaussians != MAX_GAUSSIANS else {}),
            **({'steps': args.steps} if args.steps else {}), **({'epochs': args.epochs} if args.epochs else {})}


def people_option(args):
    """remove_people false for --keep-people, sent only then (an older service does not know it)."""
    return {'remove_people': False} if args.keep_people else {}


def download(args, request, base, pid, state, save_state, fingerprint, submit):
    """Poll the job (created by submit() unless the state names one), then save the selected artifacts."""
    url = base + '/reconstructions/' + pid
    includes = list(dict.fromkeys(args.include))
    include_query = [('include', name) for name in includes]
    resuming_job = bool(state.get('job_id'))
    if resuming_job:
        job_url = url + '/jobs/' + state['job_id']
        job = request('GET', job_url, params=include_query)
    else:
        job = submit()
        job_url = urljoin(base, job.headers['Location'])
    deadline = time.monotonic() + args.timeout
    result = job.json()
    state['job_id'] = result['id']
    save_state()
    print('Job:', result['id'], flush=True)
    # An idempotent POST may already be terminal; selected downloads still need their GET manifest.
    if not resuming_job and includes and result['status'] == 'succeeded':
        job = request('GET', job_url, params=include_query)
        result = job.json()
    while result['status'] not in ('succeeded', 'failed'):
        if time.monotonic() >= deadline:
            raise TimeoutError(f'Polling timed out. The job continues; resume polling {job_url}.')
        time.sleep(retry_delay(job.headers.get('Retry-After')))
        job = request('GET', job_url, params=include_query)
        result = job.json()
    if result['status'] == 'failed':
        raise RuntimeError(result['error'])
    output = args.out / pid / result['id']
    output.mkdir(parents=True, exist_ok=True)
    receipt = {'base_url': base, 'reconstruction_id': pid, 'job': result, 'inputs_sha256': fingerprint,
               'models': args.models, 'include': includes, 'artifacts': []}
    allowed = {'both': {'point_cloud.ply', 'scene.spz'}, 'ply': {'point_cloud.ply'},
               'spz': {'scene.spz'}, 'none': set()}[args.models]
    if allowed:
        allowed.add('scale.json')
    allowed.update({'cameras': 'cameras.json', 'masks': 'masks.zip'}[name] for name in includes)
    for artifact in result['artifacts']:
        name = artifact['name']
        if name in ('', '.', '..') or Path(name).name != name or '\\' in name:
            raise ValueError('Invalid artifact filename.')
        if name not in allowed:
            continue
        # requests strips Authorization on a cross-host redirect to private object storage.
        target = output / name
        partial = target.with_suffix(target.suffix + '.part')
        with request('GET', urljoin(base, artifact['href']), stream=True) as response, partial.open('wb') as f:
            for chunk in response.iter_content(1 << 20):
                f.write(chunk)
            length = response.headers.get('Content-Length') if not response.headers.get('Content-Encoding') else None
        if length is not None and partial.stat().st_size != int(length):
            raise OSError('Incomplete artifact download: ' + name)
        partial.replace(target)
        receipt['artifacts'].append({'name': name, 'bytes': target.stat().st_size, 'sha256': sha256(target)})
        print('Saved:', target)
    if result.get('public_images_url'):   # anyone holding these downloads without a key
        for artifact in result['artifacts']:
            print('Public URL:', artifact['public_url'])
        print('Public images:', result['public_images_url'])
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


if __name__ == '__main__':
    main()
