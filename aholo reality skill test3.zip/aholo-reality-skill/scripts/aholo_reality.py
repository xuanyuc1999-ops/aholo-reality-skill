#!/usr/bin/env python3
"""Aholo Reality for agents: reconstruct photos, videos or a 360 video into 3D Gaussian models. Needs Python 3.9+ and requests.

python aholo_reality.py check                     # connection, packages and updates
python aholo_reality.py login --site SITE         # saves the user's API key, read from standard input or a hidden prompt
python aholo_reality.py run PHOTOS --out DIR      # or --video FILE (repeatable) or --insv FILE; run --help lists the options
python aholo_reality.py run --insv FILE --preset indoor --out DIR   # optional legacy quality preset
python aholo_reality.py api GET /reconstructions  # any other API request; --out FILE saves a download
The API key is kept only in ~/.aholo-reality/credentials.json and is never printed.
"""
import argparse
import getpass
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit
import uuid

SCRIPT = Path(__file__).resolve()
CREDENTIALS = Path.home() / '.aholo-reality' / 'credentials.json'
API_PATH = '/api/web-scan/v1'
KEY = re.compile(r'ws_[A-Za-z0-9_-]{43}')
# run --preset: the recommended options for a scene from a 360° (--insv) or ordinary (--video) video (T265). 4K is
# 3840 px: a 360° video's lens edge (at most the camera's), an ordinary video's longest edge (never upscaled).
PRESETS = {('insv', 'indoor'): {'fps': 2, 'image-size': 3840, 'max-gaussians': 5_000_000, 'epochs': 30},
           ('insv', 'outdoor'): {'fps': 2, 'image-size': 3840, 'max-gaussians': 15_000_000, 'epochs': 30},
           ('video', 'indoor'): {'fps': 5, 'image-size': 3840, 'max-gaussians': 5_000_000, 'epochs': 20},
           ('video', 'outdoor'): {'fps': 5, 'image-size': 3840, 'max-gaussians': 10_000_000, 'epochs': 20}}


def load_client():
    """The bundled reconstruct.py: its request() retries, sends the key only to its own origin and raises ApiError."""
    if sys.version_info < (3, 9):
        sys.exit('Python 3.9 or newer is required.')
    spec = importlib.util.spec_from_file_location('reconstruct', SCRIPT.with_name('reconstruct.py'))
    client = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(client)
    except ModuleNotFoundError as error:
        sys.exit(f'The Python package {error.name} is missing: run python -m pip install {error.name}')
    return client


def site_of(value):
    """The address the user signs in at, such as https://www.aholo3d.cn/holo-web-scan; the API is on the same host."""
    site = value.strip().rstrip('/')
    parts = urlsplit(site)
    if parts.username or parts.password or parts.query or parts.fragment or not parts.hostname:
        sys.exit('--site must be an address such as https://www.aholo3d.cn/holo-web-scan, without credentials, query or fragment.')
    if parts.scheme != 'https' and not (parts.scheme == 'http' and parts.hostname in ('localhost', '127.0.0.1', '::1')):
        sys.exit('--site must use HTTPS (HTTP only on this computer, for testing).')
    return site


def origin_of(site):
    parts = urlsplit(site)
    return f'{parts.scheme}://{parts.netloc}'


def saved():
    try:
        credentials = json.loads(CREDENTIALS.read_text())
        return credentials['site'], credentials['api_key']
    except (OSError, ValueError, KeyError, TypeError):
        return None, None


def connection():
    site, key = saved()
    if not key:
        sys.exit('Not connected. Ask the user for an API key with read and write access (Developer Center > API keys '
                 f'on their Aholo Reality site), then run: python "{SCRIPT}" login --site SITE')
    return site, origin_of(site) + API_PATH, key


def advice(error, site):
    """An API error, and what to do about the ones only the user can fix: a key that does not work or cannot write."""
    if error.status in (401, 403):
        return (f'Error: {error}\nAsk the user to create an API key with read and write access at {site}/developers/keys/ '
                f'and run: python "{SCRIPT}" login --site {site}')
    return f'Error: {error}'


def published_version(requests, site):
    """The version the site serves, or None: an address that is not the site may answer any path with a page."""
    try:
        response = requests.get(site + '/skill/VERSION', timeout=10)
    except requests.RequestException:
        return None
    version = response.text.strip() if response.ok else ''
    return version if re.fullmatch(r'[0-9a-f]{12}', version) else None


def verify(client, site, key):
    base = origin_of(site) + API_PATH
    try:
        client.client(base, key)('GET', base + '/reconstructions', params={'limit': 1})
    except client.ApiError as error:
        sys.exit(advice(error, site))
    except client.requests.RequestException as error:
        sys.exit(f'Cannot reach {site}: {error}')


def login(args):
    client = load_client()
    site = site_of(args.site) if args.site else saved()[0]
    if not site:
        sys.exit('Pass --site: the address the skill was installed from, without /skill/install.md.')
    if not published_version(client.requests, site):
        sys.exit(f'No aholo-reality-skill at {site}/skill/: pass the address the skill was installed from, without /skill/install.md.')
    key = (getpass.getpass('Aholo Reality API key (input hidden): ') if sys.stdin.isatty() else sys.stdin.readline()).strip()
    if not KEY.fullmatch(key):
        sys.exit(f'No API key was given (it starts with ws_). Ask the user to run this command in their own terminal, '
                 f'or pipe the key they gave you to it: printf "%s\\n" KEY | python "{SCRIPT}" login --site {site}')
    verify(client, site, key)
    CREDENTIALS.parent.mkdir(mode=0o700, exist_ok=True)
    os.chmod(CREDENTIALS.parent, 0o700)
    partial = CREDENTIALS.with_suffix('.tmp')
    partial.unlink(missing_ok=True)
    with os.fdopen(os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w') as f:
        json.dump({'site': site, 'api_key': key}, f)
    partial.replace(CREDENTIALS)
    print(f'Connected to {site}. The API key is saved in {CREDENTIALS}.')


def check(args):
    client = load_client()
    site, api, key = connection()
    verify(client, site, key)
    version = (SCRIPT.parents[1] / 'VERSION').read_text().strip()
    print(f'Connected to {site} (aholo-reality-skill {version}).')
    latest = published_version(client.requests, site)
    if latest and latest != version:
        print(f'A newer aholo-reality-skill is available. Ask the user before updating; to update, follow {site}/skill/install.md')


def preset(arguments):
    """Capture type selects the subject; only an explicit legacy scene preset changes quality."""
    parser = argparse.ArgumentParser(prog='aholo_reality.py run', add_help=False, allow_abbrev=False)
    kinds = ['indoor', 'outdoor', 'object']
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--capture', choices=kinds)
    group.add_argument('--preset', choices=kinds)
    parser.add_argument('--mode', choices=['scene', 'object'])
    chosen, rest = parser.parse_known_args(arguments)
    if {'-h', '--help'} & set(rest):
        print('--capture indoor|outdoor|object: video subject, using service quality defaults. '
              'Object requires ordinary video; view results on the online project page.\n'
              '--preset indoor|outdoor: optional legacy quality presets; --preset object aliases --capture object.')
        return rest
    subject = chosen.capture or chosen.preset
    if not subject:
        return rest + (['--mode', chosen.mode] if chosen.mode else [])
    given = {argument.split('=')[0] for argument in rest}
    kind = 'insv' if '--insv' in given else 'video' if '--video' in given else None
    if kind is None:
        parser.error('--capture/--preset requires --video or --insv; use --mode object for photos.')
    mode = 'object' if subject == 'object' else 'scene'
    if chosen.mode and chosen.mode != mode:
        parser.error('The capture type conflicts with --mode.')
    if kind == 'insv' and mode == 'object':
        parser.error('INSV/OSV only supports scene jobs. For an object, export a perspective video or photos first.')
    rest += ['--mode', mode]
    if chosen.capture or mode == 'object':
        return rest
    return [*(f'--{name}={value}' for name, value in PRESETS[kind, chosen.preset].items()
              if not (name == 'epochs' and '--steps' in given)), *rest]


def run(arguments):
    """reconstruct.py with the saved site and key; prints the project page as soon as the reconstruction exists."""
    arguments = preset(arguments)
    client = load_client()
    if {'-h', '--help'} & set(arguments):
        sys.argv = ['aholo_reality.py run', '--help']
        return client.main()
    site, api, key = connection()
    if any(argument.split('=')[0] == '--base-url' for argument in arguments):
        sys.exit('run uses the site from login; omit --base-url.')

    def report(*values, **options):
        print(*values, **options)
        if values[:1] == ('Reconstruction:',):
            print('Project page:', f'{site}/projects/detail/?p={values[1]}', flush=True)
    client.print = report
    os.environ['RECONSTRUCTION_API_KEY'] = key
    sys.argv = ['aholo_reality.py run', *arguments, '--base-url', api]
    try:
        client.main()
    except client.ApiError as error:
        sys.exit(advice(error, site))
    except (client.requests.RequestException, TimeoutError) as error:
        sys.exit(f'Error: {error}\nRerun the same command to resume.')
    except (RuntimeError, OSError, ValueError) as error:
        sys.exit(f'Error: {error}')


def api(args):
    """One API request on the saved site: JSON is printed, a file is saved with --out."""
    client = load_client()
    site, base, key = connection()
    parts = urlsplit(args.path)
    if parts.scheme or parts.netloc or args.path.startswith('//') or '\\' in args.path or '..' in parts.path.split('/'):
        sys.exit('PATH must be an API path such as /reconstructions or an artifact href, not a URL.')
    path = args.path if args.path.startswith(API_PATH + '/') else API_PATH + '/' + args.path.lstrip('/')
    try:
        body = json.loads(args.json) if args.json else None
    except ValueError:
        sys.exit('--json must be valid JSON.')
    # a POST's retries keep one Idempotency-Key, so a retried create returns the first result
    headers = {'Idempotency-Key': str(uuid.uuid4())} if args.method == 'POST' else None
    try:
        response = client.client(base, key)(args.method, origin_of(site) + path, json=body, headers=headers,
                                            stream=bool(args.out))
        if args.out:
            partial = args.out.with_name(args.out.name + '.part')
            with response, partial.open('wb') as f:
                for chunk in response.iter_content(1 << 20):
                    f.write(chunk)
            partial.replace(args.out)
    except client.ApiError as error:
        sys.exit(advice(error, site))
    except client.requests.RequestException as error:
        sys.exit(f'Cannot reach {site}: {error}')
    if args.out:
        print('Saved:', args.out)
    elif 'json' in response.headers.get('Content-Type', ''):
        print(json.dumps(response.json(), indent=2, ensure_ascii=False))
    elif response.content:
        sys.exit('The response is a file: add --out FILE to save it.')
    else:
        print(response.status_code, response.reason)


def main():
    if sys.argv[1:2] == ['run']:
        return run(sys.argv[2:])
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('check', help='Check the connection and whether a newer version is available')
    login_parser = commands.add_parser('login', help="Save the user's API key (from standard input or a hidden prompt)")
    login_parser.add_argument('--site', help='The address the skill was installed from, without /skill/install.md')
    commands.add_parser('run', help='Reconstruct: a photos directory, --video FILE or --insv FILE (--capture '
                        'indoor, outdoor or object); run --help lists the options')
    request_parser = commands.add_parser('api', help='Send one API request: METHOD PATH [--json BODY] [--out FILE]')
    request_parser.add_argument('method', type=str.upper, choices=['GET', 'POST', 'PUT', 'DELETE'])
    request_parser.add_argument('path', help='Path under /api/web-scan/v1, or an artifact href')
    request_parser.add_argument('--json', help='JSON request body')
    request_parser.add_argument('--out', type=Path, help='Save the response to this file')
    args = parser.parse_args()
    {'check': check, 'login': login, 'api': api}[args.command](args)


if __name__ == '__main__':
    main()
