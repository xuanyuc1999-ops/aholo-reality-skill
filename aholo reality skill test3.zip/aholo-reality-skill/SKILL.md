---

name: aholo-reality-skill

description: Reconstruct 3D Gaussian splat models from photos, ordinary videos or 360° videos (Insta360 .insv, DJI Osmo 360 .osv) with Aholo Reality, follow the progress and download the models (SPZ, PLY). Use when the user wants a 3D reconstruction, 3D scan, Gaussian splat or 3D model of a scene or object from their photos or videos (三维重建、3D 重建、高斯模型、用照片或视频生成 3D 模型).

---

# Aholo Reality

Aholo Reality reconstructs photos and videos into 3D Gaussian Splatting models in the cloud and shows each one on a

project page. `scripts/aholo_reality.py` (Python 3.9+ with `requests`) uploads, waits and downloads; paths below are

relative to this skill's directory. Reply in the user's language.

## Connect

Run `python scripts/aholo_reality.py check` before the first reconstruction in a conversation.

- Connected: go on. If it reports a newer version, ask the user whether to update; if yes, follow the install guide it names.

- Not connected, or the key is invalid: ask the user to create an API key with read and write access at

  `SITE/developers/keys/` (Developer Center › API keys; it is shown once). SITE is the address the skill was installed
  from, usually `https://www.aholo3d.cn/holo-web-scan`. Then either the user runs
  `python <this skill>/scripts/aholo_reality.py login --site SITE` in their own terminal and types the key (hidden), or
  the user gives you the key and you run `printf '%s\n' 'KEY' | python scripts/aholo_reality.py login --site SITE`.
  The key is saved only in `~/.aholo-reality/credentials.json`: never repeat it, store it elsewhere, put it in an
  argument or environment variable, or look for keys anywhere else.

- `requests` missing: `python -m pip install requests` (ask first if the user manages their own environments).

## 全程引导：先解释选项，再由用户选择

用用户的语言逐步引导，每次只问当前要决定的事。先讲可选方案、差异、推荐理由和影响，再请用户选；已给出的素材、目标或参数直接沿用。上传、轮询、下载等机械步骤自动执行，不要求用户逐项确认。

| 阶段 | 给用户的引导与选择 |
|---|---|
| 素材与连接 | 先复述已收到的素材，缺素材时说明照片目录、普通视频、原始 360 视频三条路径及要求，请用户提供对应路径。首次检查连接；若缺授权，带用户完成登录后继续。 |
| 拍摄目标 | 照片选整片场景或单个物体；视频说明室内、室外、物体三项及线上查看方式。原始 360 若目标是物体，给出导出透视视频或多视角照片两条路径，由用户选择。 |
| 首轮方案 | 先展示下方适用参数表、默认值及可选值。用户指定的值优先，未选项按默认；不把参数表变成必须逐项回复的问卷。提交前说明本轮最终参数和线上观看入口。 |
| 进度与首次验收 | 创建项目即给线上链接，并按“时间与进度”规则给预计时间。完成后直接在线上验收，指导从固定视角看目标是否完整、边缘是否重影、纹理是否清楚。物体提示在线切换环绕，拖动旋转、滚轮缩放。然后说明保留首轮或进入调优的区别。 |
| 引导调优 | 先展示该素材完整可选路线：输入或目标修正 → 增加训练量 → 提高高斯上限；同时说明可以跳过不适用项、指定合法值或直接结束。按下节解释每轮候选值和成本，最后由用户选择。选择“更高质量”不等于自动跑遍所有档位。 |
| 最终选版 | 对实际完成的候选版本列一张简表：版本、相对保留版改了什么、同一视角的观察、已知耗时或大小、预览入口。把首轮也列入候选；无法观察或未测量的写明未知。根据用户优先级给出理由，再请用户选择交付哪个版本。交付所选版本的链接、文件、复现参数，并保留其他实验。 |

## Reconstruct

```sh

python scripts/aholo_reality.py run ~/Pictures/living-room --name "Living room" --out ~/aholo/living-room

python scripts/aholo_reality.py run --video clip1.mp4 --video clip2.mp4 --capture outdoor --name "Garden" --out ~/aholo/garden

python scripts/aholo_reality.py run --insv VID_0001.insv --capture indoor --name "Hall" --out ~/aholo/hall

```

| Input | |
|---|---|
| A photos directory | JPEG, PNG or WebP directly inside: at least 12 (typically 50–300) overlapping photos of one scene or object taken from different positions |
| `--video FILE` | MP4, MOV, M4V, MKV, WebM or AVI, up to 64 GiB; repeat it for several clips of the same place. `--fps` (default 5, 0.5–60) is how many frames each second gives |
| `--insv FILE` | One Insta360 `.insv` or DJI Osmo 360 `.osv` recording, as it comes off the camera; `--fps` likewise |

- For video capture, offer **室内 / 室外 / 物体** (indoor / outdoor / object) unless the user already specified the subject. A single item is an object even if filmed indoors. Use `--capture indoor|outdoor|object`. Indoor and outdoor run scene jobs; object runs an object job. All three use service quality defaults unless the user selects overrides before submission. For photos of an object, use `--mode object`.

- `--capture object` works with ordinary video. Raw INSV/OSV supports scenes only: for an object, ask for a perspective video export or overlapping photos of the object, then follow the ordinary-video or photo path. Never silently submit it as a scene. For guided capture, keep the subject still, move around it and cover multiple heights.

- Legacy `--preset indoor|outdoor` remains available for reproducing prior runs; it changes several quality settings and is not an experiment baseline. `--preset object` is an alias for `--capture object`.

### 重建前的可选参数

先给用户看当前素材适用的参数项目，简短说明效果与代价，再采用用户选择。已有明确选择就直接沿用；用户选择默认、跳过，或原请求未指定某项时，该项使用默认值。任务已经授权且素材、目标明确时，可以在启动说明中展示选项和默认值后按默认执行，不必停下来要求逐项回答；如果用户明确正在选择或要求等待，则等其选择。不要把单纯等待超时当成新任务授权。只提供当前输入支持的选项：

| 项目 | 适用输入 | 默认 | 可选项与说明 |
|---|---|---|---|
| 抽帧帧率 `--fps` | 普通视频、INSV/OSV | 5 | 可选 2 / 5 / 10 或自定义 0.5–60；更密抽帧会增加输入数量。INSV/OSV 单位为每秒帧对。 |
| 输入分辨率 `--image-size` | 普通视频 | 源分辨率 | 原始或指定最长边 480–8192，不能超过源尺寸；不是给照片缩放的参数。 |
| 镜头边长 `--image-size` | INSV/OSV | 2560 | 可选 2560 / 3840，或 480–8192 的偶数，实际不超过源尺寸。 |
| 训练量 `--steps` 或 `--epochs` | 照片、普通视频、INSV/OSV | 服务自动 | 可自定义步数 1000–1440000，或轮数 1–1440000；轮数最终折算并限制在 1000–1440000 步。两项互斥，增加训练量通常耗时更多。 |
| 高斯上限 `--max-gaussians` | 照片、普通视频、INSV/OSV | 400 万 | 可选 400 / 800 / 1500 万，或 10–1500 万之间整数；上限不是实际点数，增大可能增加耗时与文件大小。 |
| 保留人物 `--keep-people` | 照片、普通视频、INSV/OSV | 不启用 | 目标含雕像、人偶、画中人物时可选保留，避免目标被人物遮蔽处理误删。 |
| 目标选择 | 物体照片 | 自动选主体 | 可提供 `--object-image` 与归一化 `--object-box` 配套选框；视频不提供这项。 |

例如普通视频提交前提示：「本轮默认 5 fps、源分辨率、服务自动训练、400 万高斯上限。你也可以指定帧率、分辨率、训练量或高斯上限；未指定项保持默认。」用户若选择多个启动参数，可以一并采用并记录；后续调优仍每轮只改一项。显式保留用户提供的值，禁止旧 `--preset indoor/outdoor` 隐式覆盖这张默认表。

### 时间与进度

- 每个新任务（包括调优任务）提交后，优先从该任务的线上项目页读取 Aholo 后台显示的“预计还需”和排队估时，转述为具体分钟/秒，例如“Aholo 后台预计还需 8 分 20 秒”。这是剩余时间，不是从提交起的总耗时；如果只显示排队时间，则标注“预计排队等待”，不能冒充重建耗时，也不要自行把两种估时相加。
- 已核实公开前端用 `progress.remaining` 显示剩余秒数、用 `progress.queue.wait` 显示排队等待秒数；公开 v1 `Job` 契约未提供这两个字段。优先使用已登录线上页面可见的值；以后接口若提供估时，先核实字段和单位再引用。不得把 `Retry-After`、轮询超时、已用时或训练步数当成后台预计时间。
- 后台没有估时，或当前无法读取线上估时，使用：“预计几分钟内完成重建（后台暂未提供可读取的估时，实际以任务进度为准）。”这是无后台数据时的提示，不是后台承诺。只在任务已提交且未完成时使用，不能在尚未上传完、任务失败或已完成时误报。后续收到真实估时就替换；若已经超过几分钟或仍在排队，说明当前状态和后台尚无估时，不反复重置“几分钟”提示。
- 任务完成立即报告完成并给线上入口；任务失败报告原因。后台估时变化时更新；网络中断用原命令与原 `--out` 续跑，新的实验才用新目录。

### 首轮交付与交互调优

这是对话中的选择流程。首轮完成后先交付线上项目链接和已下载模型，再问：「这版可以交付了吗？如果要改，你最想改善哪一处？」如果用户已经说明问题，直接给针对该问题的选项，不重复询问。不要根据任务成功状态推断画质，也不要自动开始第二轮。

1. **选择目标。** 用用户看得到的现象引导：主体缺块或选错、某个角度重影、纹理细节不清、中心位置异常，或保留当前版。问题多时先选一处，记下比较用的视角与部位。未看到结果时请用户描述该处，不替用户判断。
2. **选择动作和参数。** 根据下方素材顺序以及已试过的设置，只列当前适用的选项。推荐一个具体动作，写清「当前值 → 候选值、为什么试、是否需要新任务、可能增加的耗时或文件大小」。提供推荐值、自定义合法值、保留当前版三种选择；如果可以先检查原任务的蒙版或相机，优先给出这条无需重训的路径。当前设置从上次命令或任务记录读取；自动预算未知时标记为“服务自动”，不得捏造实际步数。用户已明确给出本轮参数时，直接采用合法值，无需再问。
3. **运行和比较。** 用户选定后，从当前保留版复制参数，一次只改一项；仅下载诊断文件时复用原任务，训练时用新的 `--out`。给出新旧两个结果入口、唯一主动改动的参数、同一视角要观察的差异。请用户选择「保留新版 / 回到上一版 / 结束并交付指定版」。若继续，从用户保留的版本出发，给下一项可选实验；未作选择不启动下一轮。

**增加训练量与提高高斯上限要分别讲清，再让用户选。** 不必等用户知道参数名才提及这两个选项。进入调优先概览两者，到对应实验轮再给可执行值：

| 候选实验 | 如何引导选择 |
|---|---|
| 增加训练量 | 在输入和目标正确后，若纹理或边缘仍不理想，可让模型多训练一轮作对照。例如已知上一版实际为 40,000 步，可推荐 `--steps 60000`（1.5 倍），也可选 `80000` 或合法自定义值。训练更久，不保证改善。若实际步数未知，可用服务预算规则及实际训练图片数估算并标明估算，或明确指定一个预算作探索而不声称比上一版更大。`--steps` 与 `--epochs` 二选一。 |
| 提高高斯上限 | 保持已选训练预算和输入不变，解释“上限是允许的容量，不是实际数量”。若保留版上限为 400 万，可推荐试 `--max-gaussians 8000000`；仍需对比时可选最高 1500 万，或保留原值。上限未用满时不一定有变化，耗时和模型大小可能增加。若用户两项都想试，先只增加训练量，比较并选定版本后，下一轮才只提高上限。 |

普通视频示例：「上一版是 5 fps。你提到转到椅背时有重影，可以先只试 10 fps，看同一角度的椅背轮廓有没有改善。抽帧变多，也可能增加训练时间。你要试 10 fps、指定其他帧率，还是保留这版？」不要给照片用户提供 fps，也不要给普通视频提供仅照片支持的选框参数。

**中心异常分支。** 用户说“中心点错了”时，先区分「模型形状正常，只是拖动时绕错位置」和「多个视角下模型本身错位，怀疑训练初始高斯中心有误」。前者是预览支点：优先在线上查看器检查 Look/Orbit 模式；当前 skill 不提供手动指定旋转支点的接口，不为此启动重训。后者不能仅凭成品确认原因；当前客户端没有设置初始高斯 XYZ 或导入初始点云的参数，明确告诉用户“本轮跳过初始中心修正”。可选检查同一任务的相机位姿或蒙版，或回到其他调优项；这些属于排查，不能替代直接修正。不要用 `--max-gaussians`、`--axes` 或预览支点冒充初始高斯中心控制。

### Quality experiments

Use the preflight parameters as the first baseline; unselected settings use service defaults for the selected **subject**. If the preflight choice already matches a trial value below, compare against that actual baseline instead of repeating the same setting. When the user wants to improve quality, compare the same input and viewpoints, change one setting from the retained trial, and give each new job its own `--out` (e.g. `trial-00-default`, `trial-01-fps10`). When an adjustment does not help, revert it before testing the next. Stop when the result meets the user's goal; a request for one reconstruction does not imply running the whole series.

| Input | Experiment order |
|---|---|
| Photos | Baseline → inspect masks and target selection (`--include masks` on the same job). If needed, correct one issue: use `--keep-people` for a masked statue/figure, or select the object with `--object-image` and its normalized `--object-box` together → increase training → raise the Gaussian ceiling. |
| Ordinary video | Baseline at 5 fps → compare `--fps 10` → check that `--image-size` has not limited the source resolution (omit it for native resolution; no upscaling) → increase training → raise the Gaussian ceiling. |
| Raw INSV/OSV scene | Baseline at a 2560 px lens edge → compare `--image-size 3840` if source resolution permits → vary `--fps` separately → increase training → raise the Gaussian ceiling in a separate run. |

For training, increase `--steps` relative to the observed baseline, or use `--epochs`, never both. Changing fps also changes the number of training images and can change the service's automatic step budget; record that when comparing. For the last trial, e.g. try `--max-gaussians 8000000` versus the default 4000000. `--models` and `--include` control downloads, `--axes` controls coordinates and `--parallel` controls upload concurrency; none increases detail.

### Results and navigation

**线上项目页是场景和物体的主要观看与验收入口。** 创建项目后立即提供脚本输出的 `Project page:` 链接，完成后仍用同一入口；需要登录时引导用户使用自己的账号。物体仍以 `--mode object` 重建，指导在页面的 Look/Orbit（转向/环绕）按钮切换到“环绕”，再拖动旋转、滚轮缩放。不要承诺远端页面一定自动设为环绕，也不要猜测不存在的 URL 参数。

不自动生成、打开或交付本地 `orbit.html`，不要求用户为了观看先下载模型。`--models none` 也可在线查看；默认模型下载保持原设置，下载只作为文件交付。旧实验目录中的 HTML 保留，不作为新任务的观看入口。

- `--name`: the project name on the site. `--mode object`: reconstruct the main object, not the whole scene (photos

  or videos). `--reconstruction ID`: add photos or videos to an existing reconstruction and reconstruct it again.
  `--models spz|ply|both|none` (default both); `--include cameras masks` also downloads camera poses and masks.
  `--public-access` gives the results download links that work without a key: only when the user asks to share them.
  Photos with camera poses: `--inputs inputs.json` (the cameras and each image's pose, `SITE/developers/#poses`); the
  poses are refined with the photos unless `--skip-pose-refinement` keeps them exactly as given, only for poses the
  user says are ground truth (survey, motion capture, a synthetic scene), never a phone's tracking.
  `run --help` lists every option.

- Use a new `--out` directory for every new reconstruction. After any interruption or timeout, rerun exactly the same

  command: it resumes, never uploading anything twice or starting a second job.

- Run in the background (or with your longest timeout) and read its output. Give the `Project page:` link immediately and follow the time-reporting rules above. The page shows progress and then the model in 3D.

- The models are saved in `OUT/<reconstruction>/<job>/`: `scene.spz` (compact, for web viewers),

  `point_cloud.ply` (standard 3D Gaussian Splatting PLY), `scale.json` and `receipt.json`. Report the project page
  and these paths. The models are Gaussian splats, not meshes, and their scale from images alone is relative.

## Other requests

`python scripts/aholo_reality.py api METHOD PATH [--json BODY] [--out FILE]` sends one request with the saved key to

the API (`/api/web-scan/v1` on the site's host):

- `api GET /reconstructions` lists the user's reconstructions (`?cursor=NEXT_CURSOR` for the next page).

- `api GET /reconstructions/ID/jobs` lists a reconstruction's jobs; a succeeded job's `artifacts` hold each file's `href`.

- `api GET HREF --out scene.spz` downloads one of them.

- `api GET /openapi.json --out openapi.json` saves the full contract; search it rather than reading it whole.

  The guide for people is `SITE/developers/`.

Change existing reconstructions or jobs only when the user asks.

## Errors

| Message | Then |
|---|---|
| 401, invalid or expired key | Ask for a new key and log in again (Connect) |
| 403, requires the write scope | The key needs read and write access: ask for a new one |
| This output directory belongs to different inputs | Use a new `--out` |
| update this client | Update the skill: ask the user, then follow `SITE/skill/install.md` |
| requires 12 to … valid uploaded images | More photos, or a higher `--fps` for a short video |
| a failed job or import | Its error says why; tell the user and how to capture again |
| network errors, timeouts | Rerun the same command |

Capture tips, when asked: move around the scene or object rather than turning on the spot, keep about two thirds of

each view overlapping the next, keep the light steady, and avoid blur, reflections and people moving through. Film

slowly and smoothly.

